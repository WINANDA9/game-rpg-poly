class Character {
    
    public void move() {
        System.out.println( "Character Bergerak");
    }
}