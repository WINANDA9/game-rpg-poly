class Fighter extends Hero {
    
    @Override
    public void move() {
        System.out.println( "Fighter Bergerak");
    }
}