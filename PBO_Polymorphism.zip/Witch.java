class Witch extends Enemy {
    
    @Override
    public void move() {
        System.out.println("Witch Bergerak");
    }
}